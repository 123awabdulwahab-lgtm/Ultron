# Ultron AI — Step 1

Yeh sirf shuruaat hai: ek floating "U" bubble jo tap karne par bolta hai
"Ji boss, kya hua?" — koi naya screen nahi khulta.

## GitHub pe daalne ka tareeka (sirf phone se)

1. GitHub pe naya **public/private repository** banao (naam: UltronAI).
2. GitHub app ya github.com (mobile browser) se is poore folder ke saare
   files usi structure mein upload karo (Add file → Upload files).
3. Upload hote hi **Actions** tab me build khud shuru ho jayega
   (`.github/workflows/build.yml` ki wajah se).
4. Kuch minute baad Actions run khulo → neeche **Artifacts** me
   `ultron-ai-debug-apk` milega → wahi se APK download karo.
5. APK ko phone me install karo (Settings → "Install unknown apps" ON karna
   padega Chrome/Files ke liye).
6. App kholo → "Start Ultron Bubble" dabao → overlay permission ON karo →
   wapas app kholo, phir se dabao. Ab bubble screen pe dikhega.

## Next steps (aage banayenge)
- Step 2: Bubble ko hamesha reliably background me rakhna (foreground service)
- Step 3: Wake word "Ultron" sunna + voice input
- Step 4: Gemini API se connect karke smart jawaab dena
- Step 5: Accessibility service (app automation) — sabse sensitive part,
  sirf apne phone ke liye
